# Friendship Compatibility App

A Vite + React app built from the attached questionnaire.

## What it does

1. Your friend completes the questionnaire.
2. The app triggers an email notification using `mailto:` in this starter version.
3. You open the Owner Dashboard.
4. You answer the same questions.
5. The app generates a comprehensive compatibility report with:
   - Overall score
   - Category scores
   - Strongest alignment areas
   - Conversation/growth areas
   - Side-by-side answer comparisons
   - Downloadable JSON report

## Important privacy note

The questionnaire includes sensitive categories such as politics, religion, health, mental health, medication, family planning, ethics, and personal values. The app includes a consent notice and allows users to type "prefer not to answer."

For production, do not rely on localStorage for sensitive answers. Use a secure backend with authentication, encryption, and a clear retention/deletion policy.

## Run locally

```bash
npm install
npm run dev
```

## Replace the owner email

In `src/App.jsx`, change:

```js
const OWNER_EMAIL = "your-email@example.com";
```

to your real notification email.

## Production notification options

The starter version opens an email notification through the user's mail client. For a live deployed app, connect one of these:

- EmailJS for frontend-only email notifications
- Firebase Firestore + Cloud Functions
- Supabase database + Edge Functions
- Formspree or Web3Forms webhook

## GitHub upload

Create a new GitHub repository, then run:

```bash
git init
git add .
git commit -m "Initial compatibility app"
git branch -M main
git remote add origin YOUR_REPO_URL_HERE
git push -u origin main
```
